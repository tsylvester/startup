You are a implementation planner and TDD workflow author, act accordingly. Your response will follow this style guide: 
## 1. Purpose & Scope
- Outputs are a) consumed by humans for business and technical needs, b) consumed by automated parsers, c) reprocessed by other agents in later stages.
- These styles are specifically required for the algorithms used by the humans, agents, and parsers. 
- Produce consistently structured, machine- and human-usable documents and plans.
- Ensure exhaustive detail for documents and checklists unless given specific limits; avoid summarization.

## 2.a. Checklists
- Tone: explicit, stepwise, implementation-first; avoid hand-waving.
- One-file-per-step prompts when feasible. Include filenames/paths when known.
- Use deterministic, directive language (“Generate”, “Add”, “Write”).
- generation_limits: checklist steps per milestone ≤ 200; target 120–180; max output window ~600–800 lines per checklist; slice checklists into phase/milestone files "Phase 1 {topic} Checklist.md" or similar if the anticipated output will exceed the window.
- Update the header response to show what checklists are finished and which are pending. 

## 3. Continuations 
- You are requested and strongly encouraged to continue as many times as necessary until the full completion is finished. 
- Control flags (top-level JSON fields when requested by the prompt):
  - continuation_needed: boolean
  - stop_reason: "continuation" | "token_limit" | "complete"
  - resume_cursor: { document_key: string, section_id?: string, line_hint?: number }

Example control flags:
```json
{
  "continuation_needed": true,
  "stop_reason": "continuation",
  "resume_cursor": { "document_key": "actionable_checklist", "section_id": "1.a.iii" }
}
```

## 4. Formatting

### 4.1 Status markers
- `[ ]` Unstarted
- `[✅]` Completed
- `[🚧]` In progress / partially completed
- `[⏸️]` Paused / waiting for input
- `[❓]` Uncertainty to resolve
- `[🚫]` Blocked by dependency/issue

Place the marker at the start of every actionable item.

### 4.2 Component labels
When relevant, add ONE label immediately after the marker:
`[DB]` `[RLS]` `[BE]` `[API]` `[STORE]` `[UI]` `[CLI]` `[IDE]` `[TEST-UNIT]` `[TEST-INT]` `[TEST-E2E]` `[DOCS]` `[REFACTOR]` `[PROMPT]` `[CONFIG]` `[COMMIT]` `[DEPLOY]`.

### 4.3 Numbering & indentation (exact)
* `[ ]` 1. [Label] Task instruction for `path/file.name` in `workspace`
    * `[ ]` a. [Label] Level 2 `sub-task instruction` for `file.name` (tab indented under Level 1)
        * `[ ]` i. [Label] Level 3 `detail instruction` for `function` in `file.name` (tab indented under Level 2)
- Avoid deeper nesting. If absolutely necessary, restart numbering appropriately or use a simple bullet `-` for micro-points.
- Maintain proper Markdown indentation so nesting renders correctly.

## 5. TDD Sequencing
Enforce RED → Implement → GREEN → Refactor, and label steps accordingly.

## 6. Master Plan & Milestone
- A persistent, high-level Master Plan drives iterative generation of low-level implementation checklists.
- Milestone schema fields:
  - id, title, objective, dependencies[], acceptance_criteria[], status (`[ ]`, `[🚧]`, `[✅]`)
- Organize Master Plan as phases → milestones; ensure dependency ordering.
- Do not delve into low-level individual work steps in a Master Plan or Milestones. 

## 7. Implementation Checklists
- Extreme detail; no summarization. Each step includes Inputs, Outputs, Validation.
- Use 1/a/i numbering and component labels.
- One-file-per-step prompts when possible; prefer explicit filenames/paths.
- Respect sizing & continuation policy (Section 3).

## 8. Prohibited
- Do not emit content outside the required JSON structure when specified.
- Do not rename sections, variables, or references; follow provided keys and artifact names exactly.
- Do not start another document in the same turn if continuation is required.
- Do not substitute summaries where detailed steps are requested.

## 9.a. Checklist Validation
- Status markers present at every actionable item
- Component labels used where relevant
- Numbering and indentation follow 1/a/i scheme
- Each actionable item includes Inputs, Outputs, Validation
- TDD RED→GREEN→REFACTOR sequencing present where applicable
- Milestone acceptance criteria specified 
- Sizing respected; continuation flags set when needed 

## 10.a. Milestone Skeleton
```markdown
*   `[ ]` 1. [area] Milestone <ID>: <Title>
    *   `[ ]` a. Objective: <objective>
    *   `[ ]` b. Dependencies: <ids or none>
    *   `[ ]` c. Acceptance criteria:
        *   `[ ]` i. <criterion 1>
        *   `[ ]` ii. <criterion 2>
```

## 10.b. Checklist Skeleton
```markdown
*   `[ ]` 1. [COMP] Step title
    *   `[ ]` a. Inputs: <inputs>
    *   `[ ]` b. Outputs: <outputs>
    *   `[ ]` c. Validation: <how verified>
    *   `[ ]` d. [TEST-UNIT] <RED test>
    *   `[ ]` e. [COMP] <implementation>
    *   `[ ]` f. [TEST-UNIT] <GREEN test>
    *   `[ ]` g. [COMMIT] <message>
```
Outputs are a) consumed by humans for business and technical needs, b) consumed by automated parsers, c) reprocessed by other agents in later stages. These styles are specifically required for the algorithms used by the humans, agents, and parsers. Produce consistently structured, machine- and human-usable documents and plans. Ensure exhaustive detail unless given specific limits; avoid summarization. Prefer standards when they meet constraints, are well-understood by team, and/or minimize risk and/or time-to-market. Propose alternates when explicitly requested by user, or non-standard approaches could materially improve performance, security, maintainability, or total cost under constraints. If standards and alternatives are comparable, present 1-2 viable options with concise trade-offs and a clear recommendation. Do not emit content outside the required JSON structure when specified. Do not rename sections, variables, or references; follow provided keys and artifact names exactly. Do not summarize, detailed output is requested. You are requested and strongly encouraged to continue as many times as necessary until the full completion is finished. Control flags (top-level JSON fields when requested by the prompt):
- continuation_needed: boolean
- stop_reason: "continuation" | "token_limit" | "complete"
- resume_cursor: { document_key: string, section_id?: string, line_hint?: number }

Example control flags:
```json
{
  "continuation_needed": true,
  "stop_reason": "continuation",
  "resume_cursor": { "document_key": "actionable_checklist", "section_id": "{last_completed_key}" }
}
```

Here is a HeaderContext JSON object. Use it as the source of truth for this document. We are generating multiple documents using this HeaderContext even though you're currently generating a single document.
HeaderContext: {"system_materials":{"agent_notes_to_self":"In this iteration, we focus on detailing Phase 1 (Foundational Infrastructure) and Phase 2 (Core ATS Mechanics) by explicitly sequencing MS-1 and MS-2 into an Actionable Checklist. Establishing Supabase multi-tenant configurations, Stripe webhooks, and the Inngest async queue upfront strictly prevents Vercel timeouts in later LLM phases. MS-1 will be marked as in_progress [🚧] in the updated master plan.","input_artifacts_summary":"Parsed TRD subsystems (Next.js, Supabase, Inngest, Stripe), Master Plan Phase 1/Phase 2 sequencing, and Milestone Schema nodes for MS-1 and MS-2.","stage_rationale":"Adhering to TDD best practices by forcing schema/auth validations and infrastructure mocks before building the frontend shells. By mapping Supabase, Stripe, and Inngest first, we decouple compute early, avoiding architecture refactors and meeting the rigid 4-month timeline constraint.","progress_update":"All milestones are currently unstarted [ ]. Updating Master Plan to mark MS-1 (Core Setup & Proof of Concept) as in_progress [🚧].","generation_limits":{"max_steps":200,"target_steps":"120-180","max_output_lines":"600-800"},"document_order":["actionable_checklist","updated_master_plan","advisor_recommendations"],"current_document":"actionable_checklist","exhaustiveness_requirement":"extreme detail; no summaries; each step includes inputs, outputs, validation; follow the style guide exactly","validation_checkpoint":["checklist uses style guide (status, numbering, labels)","steps are atomic and testable","dependency ordering enforced","coverage aligns to milestone acceptance criteria"],"quality_standards":["TDD sequence present","no missing dependencies","no speculative steps beyond selected milestones","clear file-by-file prompts"],"iteration_metadata":{"iteration_number":"1","previous_checklist_present":"false","previous_master_plan_present":"true"},"milestones_to_detail":["MS-1","MS-2"],"status_rules":{"completed":"[✅]","in_progress":"[🚧]","unstarted":"[ ]"}},"header_context_artifact":{"type":"header_context","document_key":"header_context","artifact_class":"header_context","file_type":"json"},"context_for_documents":[{"document_key":"actionable_checklist","content_to_include":{"milestone_ids":["MS-1","MS-2"],"index":[],"elaboration_instruction":"For each milestone from the milestone_schema, expand into a fully described work node with all the elements provided. Elaborate in dependency order. If generation limits are reached before exhausting the batch, use continuation flags.","node_skeleton":{"path":"","title":"","objective":[],"role":[],"module":[],"deps":[],"context_slice":[],"interface":[],"interface_tests":[],"interface_guards":[],"unit_tests":[],"construction":[],"source":[],"provides":[],"mocks":[],"integration_tests":[],"directionality":[],"requirements":[],"commit":[]},"milestone_summary":"MS-1 builds the database schemas, multi-tenant RLS via Supabase, establishes Stripe webhooks for limits, and scaffolds Inngest for background queues. MS-2 adds the core UI shell, jobs CRUD logic, and direct-to-S3 resume uploads."}},{"document_key":"updated_master_plan","content_to_include":{"index":["Phase 1: Foundational Infrastructure","Phase 2: Core ATS Mechanics","Phase 3: AI Intelligence Pipeline","Phase 4: Sourcing & Launch"],"executive_summary":"The Master Plan details a hyper-focused, four-sprint roadmap explicitly tailored to a 3-person team operating under a 4-month deadline. It prioritizes establishing the Supabase and Inngest foundation immediately (Phase 1) to definitively eliminate the architectural risk associated with long-running, timeout-prone AI operations on Vercel. By sequencing backend isolation and multi-tenancy first, the team secures a stable foundation for the subsequent rollout of the core UI logic (Phase 2), AI semantic screening (Phase 3), and the high-leverage Chrome Extension (Phase 4). The aggressive descoping of native B2B job board APIs in favor of a user-operated extraction tool guarantees we hit the MVP launch window while still delivering the product's core generative value.","phases":[{"name":"Phase 1: Foundational Infrastructure","objective":"Establish Supabase DB, Auth, Stripe webhooks, and Async Queue boilerplate.","technical_context":"Laying the structural multi-tenant foundation and establishing connection to Inngest event endpoints. This phase addresses the highest architectural risks immediately by decoupling heavy compute from the synchronous Next.js API paths.","implementation_strategy":"Configure Supabase CLI local development, initialize Next.js repo, wire up Stripe checkout/webhooks. Provision Inngest client and ensure webhook cryptographic validation is in place.","milestones":[{"id":"MS-1","title":"Core Setup & Proof of Concept","status":"[🚧]","objective":"Deploy baseline infrastructure and prove async timeout mitigation.","deps":[],"provides":["DB Schema","Auth JWT Context","Inngest Event Pipeline","Stripe Webhook Handlers"],"directionality":"Bottom-up infrastructure","requirements":["Supabase initialized with migrations committed via CLI","Stripe Webhooks receiving and accurately updating DB limits","Inngest dummy job processing to prove async execution without Edge timeouts","RBAC roles defined via Custom Claims"],"iteration_delta":"Transitioned to in_progress to begin checklist detailing."}]},{"name":"Phase 2: Core ATS Mechanics","objective":"Core ATS CRUD (Jobs, Pipelines) and direct-to-S3 uploads.","technical_context":"Building the UI shells and synchronous data mutations that users interact with. Bypasses Edge memory limits during PDF uploads by using presigned URLs.","implementation_strategy":"Implement shadcn components, set up Zustand for workspace state, wire S3 presigned URLs for client-side direct uploads.","milestones":[{"id":"MS-2","title":"Candidate & Job Pipelines","status":"[ ]","objective":"Enable users to create jobs and upload resumes securely.","deps":["MS-1"],"provides":["Pipeline UI","Direct Upload Mechanism","Storage Bucket Policies"],"directionality":"UI-driven CRUD","requirements":["Jobs can be created, updated, and deleted securely within Workspace boundaries","Resumes upload directly to S3 bypassing Vercel Edge memory limits","UI state accurately reflects Workspace active jobs"],"iteration_delta":"Initial baseline"}]},{"name":"Phase 3: AI Intelligence Pipeline","objective":"OpenAI Integration, pgvector search, Supabase Realtime.","technical_context":"The critical intelligence payload. Background jobs ingest text, call LLM, and write semantic vectors, returning the data over WebSockets.","implementation_strategy":"Wrap OpenAI API in Inngest steps, calculate Tiktoken limits to protect budget, validate GPT-4o output with strictly typed JSON schemas, broadcast completion over WebSockets to UI.","milestones":[{"id":"MS-3","title":"AI Screening Engine","status":"[ ]","objective":"Automated resume parsing and semantic scoring.","deps":["MS-2"],"provides":["AI Scores","Interview Questions","Realtime UI Updates"],"directionality":"Backend processing to UI update","requirements":["Zero Vercel timeouts during PDF parsing and AI scoring","LLM JSON schema validation passing definitively","WebSockets reliably hydrate UI state once Inngest pipeline completes","Strict Tiktoken budget caps enforced per request"],"iteration_delta":"Initial baseline"}]},{"name":"Phase 4: Sourcing & Launch","objective":"Chrome Extension development, QA, and Beta Launch.","technical_context":"Client-side scraping and CORS configuration to bypass native APIs. Eliminates long B2B negotiation cycles by giving power directly to the user's browser context.","implementation_strategy":"Build React Chrome extension content scripts, authenticate via Next.js session cookie, securely dispatch CORS payloads to Ingress API.","milestones":[{"id":"MS-4","title":"Chrome Extension & Beta","status":"[ ]","objective":"Finalize direct candidate sourcing and system hardening.","deps":["MS-3"],"provides":["Sourcing Workflow","End-to-End System","Client-Side Extraction Utilities"],"directionality":"Client-side ingress","requirements":["LinkedIn and targeted Job Board DOMs parsed successfully","Payloads successfully dispatched to ATS queue securely","System robustly handles varied extraction scenarios with fallback error handling"],"iteration_delta":"Initial baseline"}]}],"status_summary":{"completed":[],"in_progress":["MS-1"],"up_next":["MS-2","MS-3","MS-4"]},"status_markers":{"unstarted":"[ ]","in_progress":"[🚧]","completed":"[✅]"},"dependency_rules":["Database schemas and Auth must precede CRUD operations","Inngest worker queues must be provisioned before OpenAI API integration","Supabase Storage must be configured before PDF parsing workflows can execute","Next.js API routing and CORS policies must be established before Chrome Extension development","Infrastructure must proceed Application State","Application State must proceed AI Orchestration","AI Orchestration must proceed External Ingress"],"generation_limits":{"max_steps":200,"target_steps":"120-180","max_output_lines":"600-800"},"feature_scope":["Async AI Resume Screening & Scoring","Automated Interview Question Generation","Chrome Extension Sourcing Tool","Team Workspaces & RBAC via Supabase","Stripe Subscriptions & Metered Billing"],"features":["Asynchronous AI Resume Screening & Scoring using GPT-4o","Automated Interview Question Generation tied to specific Job Descriptions","Chrome Extension Sourcing Tool targeting LinkedIn and Job Boards","Secure Team Workspaces & RBAC enforced by PostgreSQL RLS","Stripe Subscriptions seamlessly tracking metered Token consumption"],"mvp_description":"A lightweight, AI-native Applicant Tracking System (ATS) tailored specifically for SMBs running entirely on serverless architecture with asynchronous offloading. It explicitly guarantees zero blocked UI threads by deferring heavy LLM compute (resume parsing, scoring) to background worker queues. It avoids expensive 6-12 month B2B partnership negotiations by utilizing a user-operated Chrome extension for direct DOM sourcing, achieving immediate time-to-market within the strict 4-month boundary.","market_opportunity":"Capturing tech-forward startups needing affordable, intelligent automation without enterprise vendor lock-in. The primary market lies within the highly underserved SMB segment (10-250 employees) who actively seek AI-driven productivity multipliers but cannot justify the cost or complexity of heavy incumbents like Greenhouse or Lever.","competitive_analysis":"Targeting the 'missing middle' between standalone AI wrappers and rigid enterprise incumbents. Legacy tools force restrictive workflows and keep generative AI behind massive premium paywalls. Meanwhile, niche AI parsing tools offer rapid screening but completely lack fundamental pipeline tracking and collaborative workspaces. This system integrates transparent AI directly into the baseline pipeline experience.","technical_context":"The platform is heavily reliant on Vercel Edge compute. Because Vercel enforces strict 10-second request timeouts on standard tiers, relying on synchronous Edge execution for volatile LLM generation or large PDF processing is guaranteed to fail in production. Therefore, we must rely strictly on Inngest to absorb the operational volatility of LLM latency via decoupled background jobs, syncing state back to the UI via Supabase WebSockets.","implementation_context":"A small 3-person team necessitating extreme leverage of BaaS platforms (Supabase) to minimize boilerplate DevOps. The implementation relies on strict database-level security (RLS) instead of writing bespoke application-tier authorization middleware. Fast UI iteration is powered by Shadcn components. Offloading webhooks and long-running jobs to managed platforms guarantees a maintainable, high-velocity build.","test_framework":"Jest for unit testing of AI parsing logic, Playwright for E2E user flows.","component_mapping":"Next.js App Router -> UI, Supabase -> Data Layer, Inngest -> Compute Layer.","architecture_summary":"Decoupled serverless architecture mitigating Vercel constraints. The system guarantees superior reliability, robust regulatory compliance, and rapid feature delivery by utilizing BaaS and decoupling compute. Event-driven architecture ensures zero data loss during traffic spikes and LLM rate-limit events.","architecture":"Event-Driven Serverless architecture utilizing Next.js as an orchestration client, Inngest for async background orchestration, and Supabase for real-time Postgres state and multi-tenant isolation.","services":["Next.js Frontend & API","Supabase Managed Postgres & Auth","Inngest Background Queue","Stripe Billing Engine","OpenAI GPT-4o Interface"],"components":["React Server Components","Supabase Realtime WebSockets","Chrome Extension Sourcing Client","Inngest Async Workers","Tiktoken Budget Validator","PDF Extraction Utility"],"integration_points":["OpenAI REST API for GPT-4o","Stripe Webhooks for Subscription Lifecycle Tracking","LinkedIn/Job Boards via Chrome Extension DOM parsing"],"dependency_resolution":["Native APIs replaced by Extension to bypass negotiations","Custom vector databases replaced by pgvector inside Postgres for simplicity","Vercel Serverless timeouts bypassed completely by utilizing Inngest decoupled architecture"],"frontend_stack":{"Framework":"Next.js App Router (React)","Styling":"Tailwind CSS + Radix UI (shadcn/ui)","State management":"React Context / Zustand","Realtime":"Supabase Realtime Client"},"backend_stack":{"Framework":"Next.js API Routes","Orchestration":"Inngest","Runtime":"Vercel Node.js / Edge","Auth":"Supabase GoTrue"},"data_platform":{"Database":"Supabase PostgreSQL","Vector store":"pgvector","Object storage":"Supabase Storage","Orm":"Prisma/Drizzle ORM"},"devops_tooling":{"Hosting":"Vercel","Ci cd":"GitHub Actions","Iac":"Supabase CLI","Observability":"Vercel Logs + PostHog"},"security_tooling":{"Isolation":"PostgreSQL RLS","Secrets":"Vercel Environment Vault","Tokens":"JWT"},"shared_libraries":["pdf2json","tiktoken","zod","stripe-node"],"third_party_services":["OpenAI","Stripe","Inngest"],"preserve_completed":true,"set_in_progress":"[🚧]","future_status":"[ ]","capture_iteration_delta":true}},{"document_key":"advisor_recommendations","content_to_include":{"require_comparison_matrix":true,"summarize_tradeoffs":true,"capture_final_recommendation":true,"tie_breaker_guidance":true,"comparison_matrix":[],"analysis":{"summary":"","tradeoffs":"","consensus":""},"recommendation":{"rankings":[],"tie_breakers":[]}}}]}

## UPDATE Operation: Master Plan Status Updates

You are updating the original Master Plan document. Use it as your base structure and preserve all fields verbatim except where specified below.

**Baseline Assumptions:**
- Milestones originally marked "[🚧]" (in-progress) → assume completed "[✅]" (plan regeneration indicates work finished)
- Milestones originally marked "[✅]" (completed) → remain "[✅]" (no backtracking)
- Milestones originally marked "[ ]" (not started) → MAY transition to "[🚧]" IFF all dependencies in `dependencies[]` are completed (ready for actionable checklist) AND chosen for next set of work. 

**Update Only:**
- `phases[].milestones[].status` - Apply baseline assumptions above
- `status_summary.completed[]` - Array of milestone IDs with status "[✅]"
- `status_summary.in_progress[]` - Array of milestone IDs with status "[🚧]"
- `status_summary.up_next[]` - Array of milestone IDs with status "[ ]"
- `iteration_delta` - Brief description of status changes in this iteration

**Preserve All Other Fields** - Copy exactly from input Master Plan document. The updated_master_plan milestone structure must match the master_plan milestone structure exactly. Update status markers but do not alter the milestone field vocabulary.

Replace the placeholder value for each key of the JSON object below with fully written content derived from and informed by the HeaderContext and the input Master Plan. Each field should contain the appropriate content type (strings, arrays, objects) as specified. Preserve all fields from the input Master Plan except where status updates are specified. Follow the continuation policy from the style guide by generating as much content as required to satisfy the HeaderContext: 

{"content":{"index":[],"executive_summary":"","phases":[{"name":"","objective":"","technical_context":"","implementation_strategy":"","milestones":[{"id":"","title":"","status":"[ ]","objective":"","deps":[],"provides":[],"directionality":"","requirements":[],"iteration_delta":""}]}],"status_summary":{"completed":[],"in_progress":[],"up_next":[]},"status_markers":{"unstarted":"[ ]","in_progress":"[🚧]","completed":"[✅]"},"dependency_rules":[],"generation_limits":{"max_steps":200,"target_steps":"120-180","max_output_lines":"600-800"},"feature_scope":[],"features":[],"mvp_description":"","market_opportunity":"","competitive_analysis":"","technical_context":"","implementation_context":"","test_framework":"","component_mapping":"","architecture_summary":"","architecture":"","services":[],"components":[],"integration_points":[],"dependency_resolution":[],"frontend_stack":{},"backend_stack":{},"data_platform":{},"devops_tooling":{},"security_tooling":{},"shared_libraries":[],"third_party_services":[]}}

Return only the JSON object above with all fields populated from the input Master Plan. Update only status, status_summary arrays, and iteration_delta as specified. Do not add fences or commentary outside the JSON.